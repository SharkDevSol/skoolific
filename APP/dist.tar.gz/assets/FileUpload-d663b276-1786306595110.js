import{c as x,j as s,a5 as G,y as X}from"./index-f1afec5e-1786306595110.js";import{r as v,R as J}from"./vendor-react-1c8f8aa8-1786306595110.js";import{s as p,a as c}from"./FilePreview.module-0ddb30ff-1786306595110.js";import{F as Q}from"./file-text-a9e406d6-1786306595110.js";/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Y=[["rect",{width:"20",height:"5",x:"2",y:"3",rx:"1",key:"1wp1u1"}],["path",{d:"M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8",key:"1s80jp"}],["path",{d:"M10 12h4",key:"a56b0p"}]],ee=x("archive",Y);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const se=[["path",{d:"M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z",key:"1tc9qg"}],["circle",{cx:"12",cy:"13",r:"3",key:"1vg3eu"}]],xe=x("camera",se);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const te=[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}]],re=x("file",te);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ae=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",key:"1xmnt7"}]],ne=x("image",ae);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const oe=[["path",{d:"M9 18V5l12-2v13",key:"1jmyc2"}],["circle",{cx:"6",cy:"18",r:"3",key:"fqmcym"}],["circle",{cx:"18",cy:"16",r:"3",key:"1hluhg"}]],ie=x("music",oe);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ce=[["path",{d:"M12 3v12",key:"1x0j5s"}],["path",{d:"m17 8-5-5-5 5",key:"7q97r8"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}]],le=x("upload",ce);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const de=[["path",{d:"m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",key:"ftymec"}],["rect",{x:"2",y:"6",width:"14",height:"12",rx:"2",key:"158x01"}]],pe=x("video",de),he=({file:a,onRemove:u,showPreview:j=!0,progress:h,disabled:l=!1})=>{var f;const[y,M]=v.useState(null),[d,k]=v.useState(!1),w=r=>{if(r===0)return"0 Bytes";const m=1024,g=["Bytes","KB","MB","GB"],I=Math.floor(Math.log(r)/Math.log(m));return Math.round(r/Math.pow(m,I)*100)/100+" "+g[I]},D=()=>{const r=a.type;return r.startsWith("image/")?s.jsx(ne,{size:24}):r.startsWith("video/")?s.jsx(pe,{size:24}):r.startsWith("audio/")?s.jsx(ie,{size:24}):r.includes("pdf")||r.includes("document")?s.jsx(Q,{size:24}):r.includes("zip")||r.includes("rar")||r.includes("compressed")?s.jsx(ee,{size:24}):s.jsx(re,{size:24})};v.useEffect(()=>{var m;const r=((m=a.type)==null?void 0:m.startsWith("image/"))||!a.type&&/\.(jpe?g|png|gif|webp|bmp|svg|heic)$/i.test(a.name||"");if(j&&r){const g=URL.createObjectURL(a);return M(g),()=>{URL.revokeObjectURL(g)}}},[a,j]);const $=()=>{k(!0)},z=r=>{r.stopPropagation(),!l&&u&&u()},E=r=>{(r.key==="Enter"||r.key===" ")&&(r.preventDefault(),z(r))},F=j&&!d&&(((f=a.type)==null?void 0:f.startsWith("image/"))||!a.type&&/\.(jpe?g|png|gif|webp|bmp|svg|heic)$/i.test(a.name||""));return s.jsxs("div",{className:`${p.filePreview} ${l?p.disabled:""}`,children:[s.jsx("div",{className:p.fileIconContainer,children:F&&y?s.jsx("img",{src:y,alt:a.name,className:p.imagePreview,onError:$}):s.jsx("div",{className:p.fileIcon,children:D()})}),s.jsxs("div",{className:p.fileInfo,children:[s.jsx("p",{className:p.fileName,title:a.name,children:a.name}),s.jsx("p",{className:p.fileSize,children:w(a.size)}),h!==void 0&&h<100&&s.jsx("div",{className:p.progressBar,children:s.jsx("div",{className:p.progressFill,style:{width:`${h}%`},role:"progressbar","aria-valuenow":h,"aria-valuemin":"0","aria-valuemax":"100","aria-label":`Upload progress: ${h}%`})})]}),s.jsx("button",{type:"button",onClick:z,onKeyDown:E,className:p.removeButton,"aria-label":`Remove ${a.name}`,disabled:l,tabIndex:0,children:s.jsx(G,{size:18})})]})},je=({label:a,accept:u,multiple:j=!1,maxSize:h=5*1024*1024,maxFiles:l,onChange:y,onError:M,disabled:d=!1,error:k,preview:w=!0,className:D="",value:$=[],helperText:z,required:E,...F})=>{const[f,r]=v.useState($),[m,g]=v.useState(!1),[I,L]=v.useState({}),_=v.useRef(null),R=v.useRef(null);J.useEffect(()=>{r($)},[$]);const U=`${`file-upload-${Math.random().toString(36).substr(2,9)}`}-error`,B=e=>{if(e===0)return"0 Bytes";const t=1024,n=["Bytes","KB","MB","GB"],o=Math.floor(Math.log(e)/Math.log(t));return Math.round(e/Math.pow(t,o)*100)/100+" "+n[o]},C=e=>{if(!u)return!0;const t=u.split(",").map(i=>i.trim()),n=e.type,o=e.name;return t.some(i=>{if(i.includes("*")){const N=i.split("/")[0];return n.startsWith(N+"/")}return i.startsWith(".")?o.toLowerCase().endsWith(i.toLowerCase()):n===i})},T=e=>e.size<=h,W=e=>{const t=[];return l&&f.length+e.length>l&&t.push(`Maximum ${l} file${l>1?"s":""} allowed`),e.forEach(n=>{C(n)||t.push(`${n.name}: Invalid file type`),T(n)||t.push(`${n.name}: File size exceeds ${B(h)}`)}),t},P=e=>{if(d)return;const t=Array.from(e),n=W(t);if(n.length>0){const N=n.join(", ");M&&M(N);return}const o=j?[...f,...t]:t,i=l?o.slice(0,l):o;r(i),y&&y(i),t.forEach((N,fe)=>{S(N.name)})},S=e=>{let t=0;const n=setInterval(()=>{t+=10,L(o=>({...o,[e]:t})),t>=100&&(clearInterval(n),setTimeout(()=>{L(o=>{const i={...o};return delete i[e],i})},500))},100)},V=e=>{const t=e.target.files;t&&t.length>0&&P(t),e.target.value=""},q=e=>{e.preventDefault(),e.stopPropagation(),d||g(!0)},K=e=>{e.preventDefault(),e.stopPropagation(),e.target===R.current&&g(!1)},Z=e=>{e.preventDefault(),e.stopPropagation()},A=e=>{if(e.preventDefault(),e.stopPropagation(),g(!1),d)return;const t=e.dataTransfer.files;t&&t.length>0&&P(t)},H=e=>{const t=f.filter((n,o)=>o!==e);r(t),y&&y(t)},b=()=>{!d&&_.current&&_.current.click()},O=e=>{(e.key==="Enter"||e.key===" ")&&(e.preventDefault(),b())};return s.jsxs("div",{className:`${c.fileUploadGroup} ${D}`,children:[a&&s.jsx("label",{className:c.label,children:a}),s.jsxs("div",{ref:R,className:`
          ${c.dropZone}
          ${m?c.dragging:""}
          ${d?c.disabled:""}
          ${k?c.error:""}
        `,onDragEnter:q,onDragLeave:K,onDragOver:Z,onDrop:A,onClick:b,onKeyDown:O,role:"button",tabIndex:d?-1:0,"aria-label":a||"Upload files","aria-disabled":d,"aria-describedby":k?U:void 0,children:[s.jsx("input",{ref:_,type:"file",accept:u,multiple:j,onChange:V,className:c.fileInput,disabled:d,"aria-hidden":"true",tabIndex:-1,...F}),s.jsxs("div",{className:c.dropZoneContent,children:[s.jsx(le,{className:c.uploadIcon,size:48}),s.jsx("p",{className:c.dropZoneText,children:m?s.jsx("strong",{children:"Drop files here"}):s.jsxs(s.Fragment,{children:[s.jsx("strong",{children:"Click to upload"})," or drag and drop"]})}),s.jsxs("p",{className:c.dropZoneHint,children:[u&&`Accepted formats: ${u}`,h&&` • Max size: ${B(h)}`,l&&` • Max files: ${l}`]})]})]}),k&&s.jsxs("span",{id:U,className:c.errorMessage,role:"alert","aria-live":"assertive",children:[s.jsx(X,{size:14}),k]}),f.length>0&&s.jsx("div",{className:c.fileList,children:f.map((e,t)=>s.jsx(he,{file:e,onRemove:()=>H(t),showPreview:w,progress:I[e.name],disabled:d},`${e.name}-${t}`))})]})};export{xe as C,je as F,le as U};
