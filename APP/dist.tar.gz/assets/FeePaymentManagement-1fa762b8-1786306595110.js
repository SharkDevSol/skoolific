import{j as e}from"./index-f1afec5e-1786306595110.js";import{r as c}from"./vendor-react-1c8f8aa8-1786306595110.js";import{s}from"./PaymentManagement.module-45b7acc3-1786306595110.js";import"./vendor-axios-edfcd65b-1786306595110.js";const V=()=>{const[n,b]=c.useState([]),[S,r]=c.useState([]),[h,u]=c.useState(!0),[C,a]=c.useState(!1),[T,v]=c.useState(!1),[_,P]=c.useState(null),[w,m]=c.useState("ALL"),[F,B]=c.useState(""),[g,$]=c.useState({fromDate:"",toDate:""}),[p,D]=c.useState({totalCollected:0,totalPayments:0,totalBalance:0,studentsWithBalance:0});c.useEffect(()=>{A(),I()},[w,g]);const A=async()=>{try{const t=localStorage.getItem("authToken")||localStorage.getItem("token"),l=new URLSearchParams;w!=="ALL"&&l.append("status",w),g.fromDate&&l.append("fromDate",g.fromDate),g.toDate&&l.append("toDate",g.toDate);const x=await fetch(`/api/fee-payments?${l}`,{headers:{Authorization:`Bearer ${t}`}});if(x.ok){const i=await x.json();b(i.data);const f=new Map;let j=0;i.data.forEach(y=>{const E=`${y.student_id}-${y.fee_structure_id}`,M=parseFloat(y.fee_amount||0),W=parseFloat(y.total_paid||0),O=M-W;j+=parseFloat(y.amount),f.has(E)||f.set(E,{feeAmount:M,totalPaid:W,balance:O})});let z=0,N=0;f.forEach(y=>{z+=y.balance,y.balance>0&&N++}),D({totalCollected:j,totalPayments:i.data.length,totalBalance:z,studentsWithBalance:N})}}catch(t){console.error("Error fetching payments:",t)}finally{u(!1)}},I=async()=>{try{const t=localStorage.getItem("authToken")||localStorage.getItem("token"),l=await fetch("/api/simple-fees",{headers:{Authorization:`Bearer ${t}`}});if(l.ok){const x=await l.json();r(x.data.filter(i=>i.isActive))}}catch(t){console.error("Error fetching fee structures:",t)}},R=async t=>{if(confirm("Delete this payment record?"))try{const l=localStorage.getItem("authToken")||localStorage.getItem("token");(await fetch(`/api/fee-payments/${t}`,{method:"DELETE",headers:{Authorization:`Bearer ${l}`}})).ok&&(A(),alert("Payment deleted successfully"))}catch(l){console.error("Error deleting payment:",l),alert("Failed to delete payment")}},k=t=>{P(t),v(!0)},L=t=>{const l=parseFloat(t.fee_amount||0),x=parseFloat(t.total_paid||0),i=l-x,f=i<=0,j=window.open("","_blank","width=400,height=600");j.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Receipt - ${t.receipt_number}</title>
        <style>
          @page {
            size: 105mm 148mm;
            margin: 2mm;
          }
          
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          
          body {
            font-family: Arial, sans-serif;
            padding: 2mm;
            font-size: 7pt;
            line-height: 1.1;
          }
          
          h1 {
            font-size: 10pt;
            margin-bottom: 1px;
            text-align: center;
            font-weight: bold;
          }
          
          h2 {
            font-size: 9pt;
            margin: 2mm 0 1mm 0;
            text-align: center;
            font-weight: bold;
          }
          
          h3 {
            font-size: 7pt;
            margin: 1.5mm 0 0.5mm 0;
            border-bottom: 0.5px solid #333;
            padding-bottom: 0.5mm;
            font-weight: bold;
          }
          
          p {
            margin: 0.5mm 0;
            font-size: 6pt;
          }
          
          table {
            width: 100%;
            border-collapse: collapse;
            margin: 0.5mm 0;
          }
          
          td {
            padding: 0.3mm 0;
            font-size: 6.5pt;
            vertical-align: top;
          }
          
          .header {
            text-align: center;
            border-bottom: 0.5px solid #333;
            padding-bottom: 1.5mm;
            margin-bottom: 1.5mm;
          }
          
          .section {
            margin-bottom: 1.5mm;
          }
          
          .amount-box {
            background: #f5f5f5;
            padding: 1mm;
            border: 0.5px solid #ddd;
            margin: 1mm 0;
          }
          
          .total-row {
            border-top: 0.5px solid #333;
            padding-top: 0.5mm;
            margin-top: 0.5mm;
            font-weight: bold;
          }
          
          .footer {
            border-top: 0.5px dashed #999;
            padding-top: 1mm;
            margin-top: 1.5mm;
            text-align: center;
            font-size: 5pt;
            color: #666;
          }
          
          .badge {
            display: inline-block;
            padding: 1mm 2mm;
            background: ${f?"#4CAF50":"#FF9800"};
            color: white;
            border-radius: 2mm;
            font-size: 6pt;
            font-weight: bold;
            margin: 0.5mm 0;
          }
          
          @media print {
            body {
              padding: 1mm;
            }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>SCHOOL NAME</h1>
          <p>School Address | City, State | (123) 456-7890</p>
        </div>
        
        <h2>PAYMENT RECEIPT</h2>
        <p style="text-align: center; font-weight: bold; font-size: 8pt;">${t.receipt_number}</p>
        <p style="text-align: center;"><span class="badge">${f?"✅ PAID":"⚠️ PARTIAL"}</span></p>
        
        <div class="section">
          <h3>Student & Fee Info</h3>
          <table>
            <tr>
              <td style="width: 30%;">Student:</td>
              <td style="font-weight: bold;">${t.student_name||"-"} (${t.student_id})</td>
            </tr>
            <tr>
              <td>Class:</td>
              <td style="font-weight: bold;">${t.class_name||"-"}</td>
            </tr>
            <tr>
              <td>Fee:</td>
              <td style="font-weight: bold;">${t.fee_name||"-"} (${t.fee_type==="CUSTOM"&&t.custom_fee_name?t.custom_fee_name:t.fee_type})</td>
            </tr>
            <tr>
              <td>Year/Term:</td>
              <td style="font-weight: bold;">${t.academic_year||"-"}${t.term?" / "+t.term:""}</td>
            </tr>
          </table>
        </div>
        
        <div class="section">
          <h3>Payment Info</h3>
          <table>
            <tr>
              <td style="width: 30%;">Date:</td>
              <td style="font-weight: bold;">${new Date(t.payment_date).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"2-digit"})}</td>
            </tr>
            <tr>
              <td>Amount Paid:</td>
              <td style="font-weight: bold; color: #4CAF50; font-size: 8pt;">$${parseFloat(t.amount).toFixed(2)}</td>
            </tr>
            <tr>
              <td>Method:</td>
              <td style="font-weight: bold;">${t.payment_method.replace("_"," ")}</td>
            </tr>
            ${t.reference_number?`<tr><td>Ref:</td><td style="font-weight: bold;">${t.reference_number}</td></tr>`:""}
          </table>
        </div>
        
        <div class="amount-box">
          <table style="font-size: 6.5pt;">
            <tr>
              <td>Total Fee:</td>
              <td style="text-align: right; font-weight: bold;">$${l.toFixed(2)}</td>
            </tr>
            <tr>
              <td>This Payment:</td>
              <td style="text-align: right; font-weight: bold; color: #2196F3;">$${parseFloat(t.amount).toFixed(2)}</td>
            </tr>
            <tr>
              <td>Total Paid:</td>
              <td style="text-align: right; font-weight: bold; color: #4CAF50;">$${x.toFixed(2)}</td>
            </tr>
            <tr class="total-row">
              <td style="font-size: 7pt;">Balance:</td>
              <td style="text-align: right; font-size: 8pt; color: ${f?"#4CAF50":"#f44336"};">$${i.toFixed(2)} ${f?"✅":""}</td>
            </tr>
          </table>
        </div>
        
        ${t.notes?`
        <div class="section">
          <h3>Notes</h3>
          <p style="font-style: italic; font-size: 5.5pt;">${t.notes}</p>
        </div>
        `:""}
        
        <div class="footer">
          <p style="font-weight: bold;">Thank you for your payment!</p>
          <p>Official receipt - Keep for your records</p>
          <p style="font-size: 4.5pt; margin-top: 0.5mm;">Printed: ${new Date().toLocaleString()}</p>
        </div>
      </body>
      </html>
    `),j.document.close(),setTimeout(()=>{j.print()},250)},o=()=>{$({fromDate:"",toDate:""})},d=n.filter(t=>{var l,x,i;return((l=t.receipt_number)==null?void 0:l.toLowerCase().includes(F.toLowerCase()))||((x=t.student_id)==null?void 0:x.toLowerCase().includes(F.toLowerCase()))||((i=t.student_name)==null?void 0:i.toLowerCase().includes(F.toLowerCase()))});return e.jsxs("div",{className:s.container,children:[e.jsxs("div",{className:s.header,children:[e.jsxs("div",{children:[e.jsx("h1",{children:"Fee Payment Tracking"}),e.jsx("p",{children:"Record and track payments for fee structures"})]}),e.jsx("button",{className:s.recordButton,onClick:()=>a(!0),children:"+ Record Payment"})]}),e.jsxs("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fit, minmax(250px, 1fr))",gap:"20px",marginBottom:"30px"},children:[e.jsxs("div",{style:{background:"linear-gradient(135deg, #667eea 0%, #764ba2 100%)",padding:"20px",borderRadius:"12px",color:"white",boxShadow:"0 4px 6px rgba(0,0,0,0.1)"},children:[e.jsx("div",{style:{fontSize:"0.9rem",opacity:.9,marginBottom:"8px"},children:"Total Collected"}),e.jsxs("div",{style:{fontSize:"2rem",fontWeight:"bold"},children:["$",p.totalCollected.toFixed(2)]}),e.jsxs("div",{style:{fontSize:"0.85rem",opacity:.8,marginTop:"8px"},children:[p.totalPayments," payment",p.totalPayments!==1?"s":""]})]}),e.jsxs("div",{style:{background:"linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",padding:"20px",borderRadius:"12px",color:"white",boxShadow:"0 4px 6px rgba(0,0,0,0.1)"},children:[e.jsx("div",{style:{fontSize:"0.9rem",opacity:.9,marginBottom:"8px"},children:"Total Outstanding"}),e.jsxs("div",{style:{fontSize:"2rem",fontWeight:"bold"},children:["$",p.totalBalance.toFixed(2)]}),e.jsxs("div",{style:{fontSize:"0.85rem",opacity:.8,marginTop:"8px"},children:[p.studentsWithBalance," student",p.studentsWithBalance!==1?"s":""," with balance"]})]}),e.jsxs("div",{style:{background:"linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)",padding:"20px",borderRadius:"12px",color:"white",boxShadow:"0 4px 6px rgba(0,0,0,0.1)"},children:[e.jsx("div",{style:{fontSize:"0.9rem",opacity:.9,marginBottom:"8px"},children:"Collection Rate"}),e.jsxs("div",{style:{fontSize:"2rem",fontWeight:"bold"},children:[p.totalCollected+p.totalBalance>0?(p.totalCollected/(p.totalCollected+p.totalBalance)*100).toFixed(1):0,"%"]}),e.jsx("div",{style:{fontSize:"0.85rem",opacity:.8,marginTop:"8px"},children:"of total fees"})]}),e.jsxs("div",{style:{background:"linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)",padding:"20px",borderRadius:"12px",color:"white",boxShadow:"0 4px 6px rgba(0,0,0,0.1)"},children:[e.jsx("div",{style:{fontSize:"0.9rem",opacity:.9,marginBottom:"8px"},children:"Average Payment"}),e.jsxs("div",{style:{fontSize:"2rem",fontWeight:"bold"},children:["$",p.totalPayments>0?(p.totalCollected/p.totalPayments).toFixed(2):"0.00"]}),e.jsx("div",{style:{fontSize:"0.85rem",opacity:.8,marginTop:"8px"},children:"per transaction"})]})]}),e.jsxs("div",{className:s.filters,children:[e.jsx("div",{className:s.filterTabs,children:["ALL","COMPLETED","PENDING","FAILED"].map(t=>e.jsx("button",{className:`${s.filterTab} ${w===t?s.active:""}`,onClick:()=>m(t),children:t},t))}),e.jsxs("div",{style:{display:"flex",gap:"12px",marginTop:"16px",flexWrap:"wrap",alignItems:"center"},children:[e.jsx("input",{type:"text",placeholder:"Search by receipt, student ID, or name...",className:s.searchInput,value:F,onChange:t=>B(t.target.value),style:{flex:"1",minWidth:"250px"}}),e.jsxs("div",{style:{display:"flex",gap:"8px",alignItems:"center"},children:[e.jsx("label",{style:{fontSize:"14px",color:"#666",whiteSpace:"nowrap"},children:"From:"}),e.jsx("input",{type:"date",className:s.dateInput,value:g.fromDate,onChange:t=>$({...g,fromDate:t.target.value})})]}),e.jsxs("div",{style:{display:"flex",gap:"8px",alignItems:"center"},children:[e.jsx("label",{style:{fontSize:"14px",color:"#666",whiteSpace:"nowrap"},children:"To:"}),e.jsx("input",{type:"date",className:s.dateInput,value:g.toDate,onChange:t=>$({...g,toDate:t.target.value})})]}),(g.fromDate||g.toDate)&&e.jsx("button",{onClick:o,className:s.clearButton,title:"Clear date filter",children:"✕ Clear"})]})]}),h?e.jsx("div",{className:s.loading,children:"Loading payments..."}):e.jsx("div",{className:s.tableContainer,children:e.jsxs("table",{className:s.table,children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Receipt #"}),e.jsx("th",{children:"Student ID"}),e.jsx("th",{children:"Student Name"}),e.jsx("th",{children:"Class"}),e.jsx("th",{children:"Fee Type"}),e.jsx("th",{children:"Fee Amount"}),e.jsx("th",{children:"Paid"}),e.jsx("th",{children:"Balance"}),e.jsx("th",{children:"Payment Date"}),e.jsx("th",{children:"Method"}),e.jsx("th",{children:"Reference"}),e.jsx("th",{children:"Actions"})]})}),e.jsx("tbody",{children:d.length===0?e.jsx("tr",{children:e.jsx("td",{colSpan:"10",className:s.noData,children:'No payments found. Click "Record Payment" to add one.'})}):d.map(t=>{const l=parseFloat(t.fee_amount||0),x=parseFloat(t.total_paid||0),i=l-x;return e.jsxs("tr",{children:[e.jsx("td",{className:s.receiptNumber,children:t.receipt_number}),e.jsx("td",{children:t.student_id}),e.jsx("td",{children:t.student_name||"-"}),e.jsx("td",{children:t.class_name||"-"}),e.jsx("td",{className:s.feeType,children:t.fee_type==="CUSTOM"&&t.custom_fee_name?t.custom_fee_name:t.fee_type}),e.jsxs("td",{className:s.amount,children:["$",l.toFixed(2)]}),e.jsxs("td",{className:s.amount,children:["$",x.toFixed(2)]}),e.jsxs("td",{className:s.amount,style:{color:i>0?"#f44336":"#4CAF50",fontWeight:"bold"},children:["$",i.toFixed(2),i<=0&&" ✅"]}),e.jsx("td",{children:new Date(t.payment_date).toLocaleDateString()}),e.jsx("td",{children:t.payment_method}),e.jsx("td",{children:t.reference_number||"-"}),e.jsx("td",{children:e.jsxs("div",{className:s.actions,children:[e.jsx("button",{className:s.actionButton,title:"View Details",onClick:()=>k(t),children:"👁️"}),e.jsx("button",{className:s.actionButton,title:"Print Receipt",onClick:()=>L(t),children:"🖨️"}),e.jsx("button",{className:s.actionButton,title:"Delete",onClick:()=>R(t.id),children:"🗑️"})]})})]},t.id)})})]})}),C&&e.jsx(Y,{feeStructures:S,onClose:()=>a(!1),onSuccess:()=>{a(!1),A()}}),T&&_&&e.jsx(U,{payment:_,onClose:()=>{v(!1),P(null)}})]})},Y=({feeStructures:n,onClose:b,onSuccess:S})=>{const[r,h]=c.useState({feeStructureId:"",selectedClass:"",studentId:"",studentName:"",className:"",amount:"",paymentDate:new Date().toISOString().split("T")[0],paymentMethod:"CASH",referenceNumber:"",notes:""}),[u,C]=c.useState(!1),[a,T]=c.useState(null),[v,_]=c.useState([]),[P,w]=c.useState(!1),[m,F]=c.useState(null),[B,g]=c.useState(!1),$=o=>{const d=n.find(t=>t.id===parseInt(o));console.log("Fee selected:",d),d&&(T(d),h({...r,feeStructureId:o,amount:d.amount,selectedClass:"",studentId:"",studentName:"",className:""}),_([]),d.classNames&&d.classNames.length===1&&(console.log("Auto-loading students for class:",d.classNames[0]),D(d.classNames[0]),h(t=>({...t,className:d.classNames[0]}))))},p=o=>{console.log("Class selected:",o),h({...r,selectedClass:o,className:o,studentId:"",studentName:""}),D(o)},D=async o=>{console.log("Fetching students for class:",o),w(!0);try{const d=localStorage.getItem("authToken")||localStorage.getItem("token"),t=await fetch(`/api/fee-payments/students/${o}`,{headers:{Authorization:`Bearer ${d}`}});if(console.log("Students response status:",t.status),t.ok){const l=await t.json();console.log("Students loaded:",l.data.length),_(l.data)}else console.error("Failed to fetch students:",t.status)}catch(d){console.error("Error fetching students:",d)}finally{w(!1)}},A=o=>{console.log("Student selected:",o),console.log("Available students:",v);const d=v.find(t=>String(t.student_id)===String(o));console.log("Found student:",d),d&&(h({...r,studentId:d.student_id,studentName:d.student_name,className:d.class_name||r.className}),a&&I(d.student_id,a.id))},I=async(o,d)=>{g(!0);try{const t=localStorage.getItem("authToken")||localStorage.getItem("token"),l=await fetch(`/api/fee-payments/student/${o}`,{headers:{Authorization:`Bearer ${t}`}});if(l.ok){const i=(await l.json()).data.payments.filter(N=>N.fee_structure_id===d),f=i.reduce((N,y)=>N+parseFloat(y.amount),0),j=parseFloat(a.amount),z=j-f;F({totalPaid:f,feeAmount:j,balance:z,paymentCount:i.length})}}catch(t){console.error("Error fetching student balance:",t)}finally{g(!1)}},R=async o=>{o.preventDefault(),C(!0);try{const d=localStorage.getItem("authToken")||localStorage.getItem("token"),t=await fetch("/api/fee-payments",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${d}`},body:JSON.stringify(r)}),l=await t.json();t.ok?(alert(`Payment recorded successfully! Receipt: ${l.data.receipt_number}`),S()):alert(l.error||"Failed to record payment")}catch(d){console.error("Error recording payment:",d),alert("An error occurred")}finally{C(!1)}},k=a&&a.classNames&&a.classNames.length>1,L=a&&(a.classNames&&a.classNames.length===1||k&&r.selectedClass);return e.jsx("div",{className:s.modalOverlay,onClick:b,children:e.jsxs("div",{className:s.modal,onClick:o=>o.stopPropagation(),children:[e.jsxs("div",{className:s.modalHeader,children:[e.jsx("h2",{children:"Record Fee Payment"}),e.jsx("button",{className:s.closeButton,onClick:b,children:"×"})]}),e.jsxs("form",{onSubmit:R,className:s.form,children:[e.jsxs("div",{className:s.formGroup,children:[e.jsx("label",{children:"Select Fee Structure *"}),e.jsxs("select",{required:!0,value:r.feeStructureId,onChange:o=>$(o.target.value),children:[e.jsx("option",{value:"",children:"-- Select Fee --"}),n.map(o=>e.jsxs("option",{value:o.id,children:[o.name," - ",o.feeType==="CUSTOM"&&o.customFeeName?o.customFeeName:o.feeType," ","($",parseFloat(o.amount).toFixed(2),")",o.classNames&&o.classNames.length>0&&` - Classes: ${o.classNames.join(", ")}`]},o.id))]})]}),a&&e.jsxs("div",{className:s.feeInfo,style:{background:"#f0f7ff",padding:"15px",borderRadius:"8px",marginBottom:"15px",border:"1px solid #2196F3"},children:[e.jsxs("p",{children:[e.jsx("strong",{children:"Fee:"})," ",a.name]}),e.jsxs("p",{children:[e.jsx("strong",{children:"Type:"})," ",a.feeType==="CUSTOM"&&a.customFeeName?a.customFeeName:a.feeType]}),e.jsxs("p",{children:[e.jsx("strong",{children:"Amount:"})," $",parseFloat(a.amount).toFixed(2)]}),e.jsxs("p",{children:[e.jsx("strong",{children:"Academic Year:"})," ",a.academicYear]}),a.term&&e.jsxs("p",{children:[e.jsx("strong",{children:"Term:"})," ",a.term]}),a.classNames&&a.classNames.length>0&&e.jsxs("p",{children:[e.jsx("strong",{children:"Classes:"})," ",a.classNames.join(", ")]})]}),k&&e.jsxs("div",{className:s.formGroup,children:[e.jsx("label",{children:"Select Class *"}),e.jsxs("select",{required:!0,value:r.selectedClass,onChange:o=>p(o.target.value),children:[e.jsx("option",{value:"",children:"-- Select Class --"}),a.classNames.map(o=>e.jsx("option",{value:o,children:o},o))]})]}),L&&e.jsxs("div",{className:s.formGroup,children:[e.jsx("label",{children:"Select Student *"}),P?e.jsx("div",{style:{padding:"10px",textAlign:"center",color:"#666"},children:"Loading students..."}):v.length===0?e.jsx("div",{style:{padding:"10px",background:"#fff3cd",border:"1px solid #ffc107",borderRadius:"4px"},children:"No students found in this class"}):e.jsxs("select",{required:!0,value:r.studentId,onChange:o=>A(o.target.value),children:[e.jsx("option",{value:"",children:"-- Select Student --"}),v.map(o=>e.jsxs("option",{value:o.student_id,children:[o.student_name," (",o.student_id,")"]},o.student_id))]})]}),r.studentId&&r.studentName&&e.jsxs("div",{style:{background:"#e8f5e9",padding:"12px",borderRadius:"8px",marginBottom:"15px",border:"1px solid #4CAF50"},children:[e.jsxs("p",{style:{margin:"4px 0"},children:[e.jsx("strong",{children:"Student:"})," ",r.studentName]}),e.jsxs("p",{style:{margin:"4px 0"},children:[e.jsx("strong",{children:"Student ID:"})," ",r.studentId]}),e.jsxs("p",{style:{margin:"4px 0"},children:[e.jsx("strong",{children:"Class:"})," ",r.className]}),B?e.jsx("p",{style:{margin:"8px 0",color:"#666",fontStyle:"italic"},children:"Loading payment history..."}):m&&e.jsxs("div",{style:{marginTop:"12px",paddingTop:"12px",borderTop:"1px solid #4CAF50"},children:[e.jsxs("p",{style:{margin:"4px 0"},children:[e.jsx("strong",{children:"Fee Amount:"})," $",m.feeAmount.toFixed(2)]}),e.jsxs("p",{style:{margin:"4px 0"},children:[e.jsx("strong",{children:"Already Paid:"})," $",m.totalPaid.toFixed(2),m.paymentCount>0&&` (${m.paymentCount} payment${m.paymentCount>1?"s":""})`]}),e.jsxs("p",{style:{margin:"4px 0",fontSize:"1.1rem",color:m.balance>0?"#f44336":"#4CAF50",fontWeight:"bold"},children:[e.jsx("strong",{children:"Balance Due:"})," $",m.balance.toFixed(2)]}),m.balance<=0&&e.jsx("p",{style:{margin:"8px 0",padding:"8px",background:"#c8e6c9",borderRadius:"4px",color:"#2e7d32",fontWeight:"bold"},children:"✅ This fee is fully paid!"}),m.balance>0&&m.balance<m.feeAmount&&e.jsxs("p",{style:{margin:"8px 0",padding:"8px",background:"#fff3cd",borderRadius:"4px",color:"#856404"},children:["⚠️ Partial payment received. Remaining: $",m.balance.toFixed(2)]})]})]}),e.jsxs("div",{className:s.formGroup,children:[e.jsx("label",{children:"Amount *"}),e.jsx("input",{type:"number",step:"0.01",required:!0,value:r.amount,onChange:o=>h({...r,amount:o.target.value}),placeholder:"0.00"}),e.jsx("small",{style:{color:"#666",display:"block",marginTop:"5px"},children:"Default amount from fee structure. You can adjust if needed."})]}),e.jsxs("div",{className:s.formRow,children:[e.jsxs("div",{className:s.formGroup,children:[e.jsx("label",{children:"Payment Date *"}),e.jsx("input",{type:"date",required:!0,value:r.paymentDate,onChange:o=>h({...r,paymentDate:o.target.value})})]}),e.jsxs("div",{className:s.formGroup,children:[e.jsx("label",{children:"Payment Method *"}),e.jsxs("select",{required:!0,value:r.paymentMethod,onChange:o=>h({...r,paymentMethod:o.target.value}),children:[e.jsx("option",{value:"CASH",children:"Cash"}),e.jsx("option",{value:"BANK_TRANSFER",children:"Bank Transfer"}),e.jsx("option",{value:"CHEQUE",children:"Cheque"}),e.jsx("option",{value:"CARD",children:"Card"}),e.jsx("option",{value:"ONLINE",children:"Online"}),e.jsx("option",{value:"MOBILE_MONEY",children:"Mobile Money"})]})]})]}),e.jsxs("div",{className:s.formGroup,children:[e.jsxs("label",{children:["Reference Number ",r.paymentMethod!=="CASH"&&"*"]}),e.jsx("input",{type:"text",required:r.paymentMethod!=="CASH",value:r.referenceNumber,onChange:o=>h({...r,referenceNumber:o.target.value}),placeholder:r.paymentMethod==="CASH"?"Optional for cash payments":"Required for non-cash payments"}),r.paymentMethod!=="CASH"&&e.jsxs("small",{style:{color:"#f44336",display:"block",marginTop:"5px"},children:["* Reference number is required for ",r.paymentMethod.replace("_"," ").toLowerCase()," payments"]})]}),e.jsxs("div",{className:s.formGroup,children:[e.jsx("label",{children:"Notes"}),e.jsx("textarea",{value:r.notes,onChange:o=>h({...r,notes:o.target.value}),placeholder:"Additional notes (optional)",rows:"3",style:{width:"100%",padding:"10px",borderRadius:"4px",border:"1px solid #ddd"}})]}),e.jsxs("div",{className:s.modalActions,children:[e.jsx("button",{type:"button",onClick:b,className:s.cancelButton,children:"Cancel"}),e.jsx("button",{type:"submit",disabled:u||!r.studentId,className:s.submitButton,children:u?"Recording...":"Record Payment"})]})]})]})})},U=({payment:n,onClose:b})=>{const S=parseFloat(n.fee_amount||0),r=parseFloat(n.total_paid||0),h=S-r,u=h<=0,C=()=>{const a=window.open("","_blank","width=400,height=600");if(!document.getElementById("printable-receipt")){alert("Receipt content not found");return}a.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Receipt - ${n.receipt_number}</title>
        <style>
          @page {
            size: 105mm 148mm;
            margin: 5mm;
          }
          
          body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 10px;
            font-size: 10pt;
            line-height: 1.4;
          }
          
          h1 {
            font-size: 14pt;
            margin: 0 0 5px 0;
            text-align: center;
          }
          
          h2 {
            font-size: 12pt;
            margin: 10px 0 5px 0;
            text-align: center;
          }
          
          h3 {
            font-size: 10pt;
            margin: 10px 0 5px 0;
            border-bottom: 2px solid #333;
            padding-bottom: 3px;
          }
          
          p {
            margin: 3px 0;
            font-size: 9pt;
          }
          
          table {
            width: 100%;
            border-collapse: collapse;
            margin: 5px 0;
          }
          
          td {
            padding: 3px 0;
            font-size: 9pt;
          }
          
          .header {
            text-align: center;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
            margin-bottom: 10px;
          }
          
          .section {
            margin-bottom: 10px;
          }
          
          .amount-box {
            background: #f5f5f5;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 5px;
            margin: 10px 0;
          }
          
          .total-row {
            border-top: 2px solid #333;
            padding-top: 5px;
            margin-top: 5px;
            font-weight: bold;
          }
          
          .footer {
            border-top: 2px dashed #999;
            padding-top: 10px;
            margin-top: 15px;
            text-align: center;
            font-size: 8pt;
            color: #666;
          }
          
          .badge {
            display: inline-block;
            padding: 5px 12px;
            background: ${u?"#4CAF50":"#FF9800"};
            color: white;
            border-radius: 15px;
            font-size: 9pt;
            font-weight: bold;
            margin: 5px 0;
          }
          
          @media print {
            body {
              margin: 0;
              padding: 5mm;
            }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>SCHOOL NAME</h1>
          <p>School Address Line 1</p>
          <p>City, State, ZIP Code</p>
          <p>Phone: (123) 456-7890 | Email: info@school.com</p>
        </div>
        
        <h2>PAYMENT RECEIPT</h2>
        <p style="text-align: center; font-weight: bold; font-size: 11pt;">${n.receipt_number}</p>
        <p style="text-align: center;"><span class="badge">${u?"✅ FULLY PAID":"⚠️ PARTIAL PAYMENT"}</span></p>
        
        <div class="section">
          <h3>Student Information</h3>
          <table>
            <tr>
              <td style="width: 40%;">Student ID:</td>
              <td style="font-weight: bold;">${n.student_id}</td>
            </tr>
            <tr>
              <td>Student Name:</td>
              <td style="font-weight: bold;">${n.student_name||"-"}</td>
            </tr>
            <tr>
              <td>Class:</td>
              <td style="font-weight: bold;">${n.class_name||"-"}</td>
            </tr>
          </table>
        </div>
        
        <div class="section">
          <h3>Fee Information</h3>
          <table>
            <tr>
              <td style="width: 40%;">Fee Name:</td>
              <td style="font-weight: bold;">${n.fee_name||"-"}</td>
            </tr>
            <tr>
              <td>Fee Type:</td>
              <td style="font-weight: bold;">${n.fee_type==="CUSTOM"&&n.custom_fee_name?n.custom_fee_name:n.fee_type}</td>
            </tr>
            <tr>
              <td>Academic Year:</td>
              <td style="font-weight: bold;">${n.academic_year||"-"}</td>
            </tr>
            ${n.term?`<tr><td>Term:</td><td style="font-weight: bold;">${n.term}</td></tr>`:""}
          </table>
        </div>
        
        <div class="section">
          <h3>Payment Details</h3>
          <table>
            <tr>
              <td style="width: 40%;">Payment Date:</td>
              <td style="font-weight: bold;">${new Date(n.payment_date).toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"})}</td>
            </tr>
            <tr>
              <td>Amount Paid:</td>
              <td style="font-weight: bold; color: #4CAF50; font-size: 12pt;">$${parseFloat(n.amount).toFixed(2)}</td>
            </tr>
            <tr>
              <td>Payment Method:</td>
              <td style="font-weight: bold;">${n.payment_method.replace("_"," ")}</td>
            </tr>
            ${n.reference_number?`<tr><td>Reference Number:</td><td style="font-weight: bold;">${n.reference_number}</td></tr>`:""}
          </table>
        </div>
        
        <div class="amount-box">
          <h3 style="margin-top: 0;">Amount Breakdown</h3>
          <table>
            <tr>
              <td>Total Fee Amount:</td>
              <td style="text-align: right; font-weight: bold;">$${S.toFixed(2)}</td>
            </tr>
            <tr>
              <td>This Payment:</td>
              <td style="text-align: right; font-weight: bold; color: #2196F3;">$${parseFloat(n.amount).toFixed(2)}</td>
            </tr>
            <tr>
              <td>Total Paid to Date:</td>
              <td style="text-align: right; font-weight: bold; color: #4CAF50;">$${r.toFixed(2)}</td>
            </tr>
            <tr class="total-row">
              <td style="font-size: 11pt;">Balance Due:</td>
              <td style="text-align: right; font-size: 13pt; color: ${u?"#4CAF50":"#f44336"};">$${h.toFixed(2)} ${u?"✅":""}</td>
            </tr>
          </table>
        </div>
        
        ${n.notes?`
        <div class="section">
          <h3>Notes</h3>
          <p style="background: #f8f9fa; padding: 8px; border-radius: 5px; font-style: italic;">${n.notes}</p>
        </div>
        `:""}
        
        <div class="footer">
          <p style="font-weight: bold;">Thank you for your payment!</p>
          <p>This is an official receipt. Please keep it for your records.</p>
          <p style="font-size: 7pt; margin-top: 8px;">Printed on: ${new Date().toLocaleString()}</p>
          <p style="font-size: 7pt;">Receipt ID: ${n.id} | Created: ${new Date(n.created_at).toLocaleString()}</p>
        </div>
      </body>
      </html>
    `),a.document.close(),setTimeout(()=>{a.print()},250)};return e.jsx("div",{className:s.modalOverlay,onClick:b,children:e.jsxs("div",{className:s.modal,onClick:a=>a.stopPropagation(),style:{maxWidth:"700px"},children:[e.jsxs("div",{className:`${s.modalHeader} no-print`,children:[e.jsx("h2",{children:"Payment Details"}),e.jsx("button",{className:s.closeButton,onClick:b,children:"×"})]}),e.jsxs("div",{className:s.form,children:[e.jsx("div",{className:"no-print",style:{marginBottom:"20px",textAlign:"center"},children:e.jsx("button",{onClick:C,style:{background:"linear-gradient(135deg, #667eea 0%, #764ba2 100%)",color:"white",border:"none",padding:"12px 32px",borderRadius:"8px",fontSize:"16px",fontWeight:"600",cursor:"pointer",boxShadow:"0 4px 12px rgba(102, 126, 234, 0.4)",transition:"transform 0.2s"},onMouseOver:a=>a.target.style.transform="translateY(-2px)",onMouseOut:a=>a.target.style.transform="translateY(0)",children:"🖨️ Print Receipt (A6)"})}),e.jsxs("div",{className:"receipt-content",id:"printable-receipt",style:{padding:"20px",background:"white"},children:[e.jsxs("div",{style:{textAlign:"center",marginBottom:"20px",paddingBottom:"15px",borderBottom:"2px solid #333"},children:[e.jsx("h1",{style:{fontSize:"1.5rem",fontWeight:"bold",margin:"0 0 8px 0",color:"#333"},children:"SCHOOL NAME"}),e.jsx("p",{style:{fontSize:"0.85rem",margin:"4px 0",color:"#666"},children:"School Address Line 1"}),e.jsx("p",{style:{fontSize:"0.85rem",margin:"4px 0",color:"#666"},children:"City, State, ZIP Code"}),e.jsx("p",{style:{fontSize:"0.85rem",margin:"4px 0",color:"#666"},children:"Phone: (123) 456-7890 | Email: info@school.com"})]}),e.jsxs("div",{style:{textAlign:"center",marginBottom:"20px"},children:[e.jsx("h2",{style:{fontSize:"1.3rem",fontWeight:"bold",margin:"0 0 8px 0",color:"#333",textTransform:"uppercase",letterSpacing:"1px"},children:"PAYMENT RECEIPT"}),e.jsx("div",{style:{fontSize:"1.1rem",fontWeight:"600",color:"#667eea",letterSpacing:"0.5px"},children:n.receipt_number})]}),e.jsx("div",{style:{textAlign:"center",marginBottom:"20px"},children:e.jsx("span",{style:{display:"inline-block",padding:"6px 16px",background:u?"#4CAF50":"#FF9800",color:"white",borderRadius:"20px",fontSize:"0.9rem",fontWeight:"600"},children:u?"✅ FULLY PAID":"⚠️ PARTIAL PAYMENT"})}),e.jsxs("div",{style:{marginBottom:"20px"},children:[e.jsx("h3",{style:{fontSize:"1rem",fontWeight:"600",marginBottom:"12px",color:"#333",borderBottom:"2px solid #4CAF50",paddingBottom:"6px",textTransform:"uppercase"},children:"Student Information"}),e.jsx("table",{style:{width:"100%",fontSize:"0.9rem"},children:e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{style:{padding:"4px 0",color:"#666",width:"40%"},children:"Student ID:"}),e.jsx("td",{style:{padding:"4px 0",fontWeight:"600",color:"#333"},children:n.student_id})]}),e.jsxs("tr",{children:[e.jsx("td",{style:{padding:"4px 0",color:"#666"},children:"Student Name:"}),e.jsx("td",{style:{padding:"4px 0",fontWeight:"600",color:"#333"},children:n.student_name||"-"})]}),e.jsxs("tr",{children:[e.jsx("td",{style:{padding:"4px 0",color:"#666"},children:"Class:"}),e.jsx("td",{style:{padding:"4px 0",fontWeight:"600",color:"#333"},children:n.class_name||"-"})]})]})})]}),e.jsxs("div",{style:{marginBottom:"20px"},children:[e.jsx("h3",{style:{fontSize:"1rem",fontWeight:"600",marginBottom:"12px",color:"#333",borderBottom:"2px solid #2196F3",paddingBottom:"6px",textTransform:"uppercase"},children:"Fee Information"}),e.jsx("table",{style:{width:"100%",fontSize:"0.9rem"},children:e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{style:{padding:"4px 0",color:"#666",width:"40%"},children:"Fee Name:"}),e.jsx("td",{style:{padding:"4px 0",fontWeight:"600",color:"#333"},children:n.fee_name||"-"})]}),e.jsxs("tr",{children:[e.jsx("td",{style:{padding:"4px 0",color:"#666"},children:"Fee Type:"}),e.jsx("td",{style:{padding:"4px 0",fontWeight:"600",color:"#2196F3"},children:n.fee_type==="CUSTOM"&&n.custom_fee_name?n.custom_fee_name:n.fee_type})]}),e.jsxs("tr",{children:[e.jsx("td",{style:{padding:"4px 0",color:"#666"},children:"Academic Year:"}),e.jsx("td",{style:{padding:"4px 0",fontWeight:"600",color:"#333"},children:n.academic_year||"-"})]}),n.term&&e.jsxs("tr",{children:[e.jsx("td",{style:{padding:"4px 0",color:"#666"},children:"Term:"}),e.jsx("td",{style:{padding:"4px 0",fontWeight:"600",color:"#333"},children:n.term})]})]})})]}),e.jsxs("div",{style:{marginBottom:"20px"},children:[e.jsx("h3",{style:{fontSize:"1rem",fontWeight:"600",marginBottom:"12px",color:"#333",borderBottom:"2px solid #FF9800",paddingBottom:"6px",textTransform:"uppercase"},children:"Payment Details"}),e.jsx("table",{style:{width:"100%",fontSize:"0.9rem"},children:e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{style:{padding:"4px 0",color:"#666",width:"40%"},children:"Payment Date:"}),e.jsx("td",{style:{padding:"4px 0",fontWeight:"600",color:"#333"},children:new Date(n.payment_date).toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"})})]}),e.jsxs("tr",{children:[e.jsx("td",{style:{padding:"4px 0",color:"#666"},children:"Payment Method:"}),e.jsx("td",{style:{padding:"4px 0",fontWeight:"600",color:"#333"},children:n.payment_method.replace("_"," ")})]}),n.reference_number&&e.jsxs("tr",{children:[e.jsx("td",{style:{padding:"4px 0",color:"#666"},children:"Reference Number:"}),e.jsx("td",{style:{padding:"4px 0",fontWeight:"600",color:"#333"},children:n.reference_number})]})]})})]}),e.jsxs("div",{style:{background:"#f8f9fa",padding:"15px",borderRadius:"8px",border:"2px solid #ddd",marginBottom:"20px"},children:[e.jsx("h3",{style:{fontSize:"1rem",fontWeight:"600",marginBottom:"12px",color:"#333",textTransform:"uppercase"},children:"Amount Breakdown"}),e.jsx("table",{style:{width:"100%",fontSize:"0.95rem"},children:e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{style:{padding:"6px 0",color:"#666"},children:"Total Fee Amount:"}),e.jsxs("td",{style:{padding:"6px 0",textAlign:"right",fontWeight:"600",color:"#333"},children:["$",S.toFixed(2)]})]}),e.jsxs("tr",{children:[e.jsx("td",{style:{padding:"6px 0",color:"#666"},children:"This Payment:"}),e.jsxs("td",{style:{padding:"6px 0",textAlign:"right",fontWeight:"600",color:"#2196F3"},children:["$",parseFloat(n.amount).toFixed(2)]})]}),e.jsxs("tr",{children:[e.jsx("td",{style:{padding:"6px 0",color:"#666"},children:"Total Paid to Date:"}),e.jsxs("td",{style:{padding:"6px 0",textAlign:"right",fontWeight:"600",color:"#4CAF50"},children:["$",r.toFixed(2)]})]}),e.jsxs("tr",{style:{borderTop:"2px solid #333"},children:[e.jsx("td",{style:{padding:"10px 0 0 0",fontSize:"1.1rem",fontWeight:"bold",color:"#333"},children:"Balance Due:"}),e.jsxs("td",{style:{padding:"10px 0 0 0",textAlign:"right",fontSize:"1.3rem",fontWeight:"bold",color:u?"#4CAF50":"#f44336"},children:["$",h.toFixed(2),u&&" ✅"]})]})]})})]}),n.notes&&e.jsxs("div",{style:{marginBottom:"20px"},children:[e.jsx("h3",{style:{fontSize:"0.95rem",fontWeight:"600",marginBottom:"8px",color:"#333"},children:"Notes:"}),e.jsx("div",{style:{background:"#f8f9fa",padding:"10px",borderRadius:"6px",fontSize:"0.85rem",color:"#666",fontStyle:"italic",border:"1px solid #e0e0e0"},children:n.notes})]}),e.jsxs("div",{className:"print-only",style:{marginTop:"30px",paddingTop:"15px",borderTop:"2px dashed #999",textAlign:"center",fontSize:"0.8rem",color:"#666"},children:[e.jsx("p",{style:{margin:"6px 0",fontWeight:"600"},children:"Thank you for your payment!"}),e.jsx("p",{style:{margin:"6px 0"},children:"This is an official receipt. Please keep it for your records."}),e.jsxs("p",{style:{margin:"6px 0",fontSize:"0.75rem",color:"#999"},children:["Printed on: ",new Date().toLocaleString()]}),e.jsxs("p",{style:{margin:"10px 0 0 0",fontSize:"0.75rem",color:"#999"},children:["Receipt ID: ",n.id," | Created: ",new Date(n.created_at).toLocaleString()]})]})]}),e.jsx("div",{className:`${s.modalActions} no-print`,style:{marginTop:"24px"},children:e.jsx("button",{onClick:b,className:s.submitButton,style:{width:"100%"},children:"Close"})})]})]})})};export{V as default};
